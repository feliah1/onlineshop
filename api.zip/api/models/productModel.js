const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    productName: {
      type: String,
      unique: true,
    },
    price: {
      type: Number,
      unique: true,
    },
    description: {
      type: String,
      unique: true,
    },
    category: {
      type: String,
      unique: true,
    },
    quantity: {
      type: Number,
      unique: true,
    },
    productStatus: {
      type: String,
      unique: true,
    }
  })

  const Product = mongoose.model("product", productSchema)
  module.exports = Product