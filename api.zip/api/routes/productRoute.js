// const express = require("express")
// const router = express.Router()
// const { createProduct } = require("../controllers/itemInventory")

// router.route("/createProduct").post(createProduct)

// module.exports = router
