// const Product = require("../models/productModel");

// exports.register = async (req, res, next) => {
//     const {productName, price, description, category, quantity, productStatus, image} = req.body
//     try {
//       await User.create({
//         productName, 
//         price, 
//         description, 
//         category, 
//         quantity, 
//         productStatus, 
//         image
//       }).then(user =>
//         res.status(200).json({
//           message: "Product successfully created",
//           productName,
//         })
//       )
//     } catch (err) {
//       res.status(401).json({
//         message: "Product not successful created",
//         error: error.message,
//       })
//     }
//   }